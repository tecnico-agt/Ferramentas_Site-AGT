#include "Dwin_T5L1H.h"
#include  "i2c.h"
#include "crc16.h"
#include "Sys.h"
#include "Uart.h"
//=============T5L_S4=115200=====================





/****************************************************************************/
void    Main()
{		  
       Sys_Cpu_Init();
       uart_init();
       while(1)
			{			
				    Clock();
				   if(Count_num1==0) 
					 {
						 Sw_Data_Send ();//�����Զ��ϴ�
						 Count_num1=100;
					 }
           uart_frame_deal();//�������ݴ���
			}	
}




